"""
extract_text_emotion.py
- Uses TextBlob for polarity and maps to a coarse emotion label.
- Input: data/preprocessed_texts.csv
- Output: results/text_predictions.json
"""
import argparse
import json
import pandas as pd
from textblob import TextBlob
from pathlib import Path

def map_polarity_to_emotion(polarity, subjectivity):
    # Simple rule-based mapping (example)
    if polarity >= 0.5:
        return "Happy"
    if polarity <= -0.5:
        return "Angry"
    if -0.5 < polarity < -0.1:
        return "Sad"
    if -0.1 <= polarity <= 0.1:
        return "Neutral"
    return "Mixed"

def extract_text_emotions(in_csv, out_json):
    df = pd.read_csv(in_csv)
    results = []
    for _, r in df.iterrows():
        text = str(r["text"])
        tb = TextBlob(text)
        polarity = tb.sentiment.polarity
        subjectivity = tb.sentiment.subjectivity
        emo = map_polarity_to_emotion(polarity, subjectivity)
        results.append({
            "id": r["id"],
            "text": text,
            "polarity": float(polarity),
            "subjectivity": float(subjectivity),
            "text_emotion": emo
        })
    Path(out_json).parent.mkdir(parents=True, exist_ok=True)
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f"[+] Saved text predictions to {out_json}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--in_csv", default="data/preprocessed_texts.csv")
    parser.add_argument("--out_json", default="results/text_predictions.json")
    args = parser.parse_args()
    extract_text_emotions(args.in_csv, args.out_json)
