"""
fuse_and_eval.py
- Loads text and image predictions, fuses them using weights, computes simple accuracy if ground-truth provided.
- Input: results/text_predictions.json, results/image_predictions.json
- Output: results/fused_predictions.json, results/eval_report.csv
"""
import argparse
import json
from pathlib import Path
import pandas as pd
from collections import Counter

def load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def simple_label_vector(label):
    # convert label to one-hot vector using fixed mapping
    cats = ["Happy","Sad","Angry","Fearful","Disgust","Surprised","Neutral","Mixed"]
    vec = [1 if c==label else 0 for c in cats]
    return vec, cats

def fuse_instance(t_pred, v_pred, wt=0.5, wv=0.5):
    t_vec, cats = simple_label_vector(t_pred["text_emotion"])
    v_vec, _ = simple_label_vector(v_pred["image_emotion"])
    fused = [wt*tv + wv*vv for tv,vv in zip(t_vec, v_vec)]
    idx = int(max(range(len(fused)), key=lambda i: fused[i]))
    return cats[idx], fused[idx]

def fuse_all(text_json, image_json, weights, out_json):
    txt = load_json(text_json)
    img = load_json(image_json)
    img_map = {p["id"]: p for p in img}
    fused_records = []
    for rec in txt:
        rid = rec["id"]
        if rid not in img_map:
            continue
        img_rec = img_map[rid]
        for wt,wv in weights:
            memo, score = fuse_instance(rec, img_rec, wt, wv)
            fused_records.append({
                "id": rid, "wt": wt, "wv": wv,
                "text_emotion": rec["text_emotion"],
                "image_emotion": img_rec["image_emotion"],
                "fused_emotion": memo, "fused_score": float(score)
            })
    Path(out_json).parent.mkdir(parents=True, exist_ok=True)
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(fused_records, f, indent=2)
    print(f"[+] Saved fused predictions to {out_json}")
    return fused_records

def simple_eval(fused_records, gt_csv=None):
    # If GT is provided, compute simple accuracy per weight config
    df = pd.DataFrame(fused_records)
    if gt_csv and Path(gt_csv).exists():
        gt = pd.read_csv(gt_csv)  # expects columns id, gt_emotion
        df = df.merge(gt, on="id", how="left")
        reports = []
        for (wt,wv), g in df.groupby(["wt","wv"]):
            sub = g.dropna(subset=["gt_emotion"])
            if len(sub)==0:
                continue
            acc = (sub["fused_emotion"] == sub["gt_emotion"]).mean()
            reports.append({"wt": wt, "wv": wv, "accuracy": float(acc), "n": len(sub)})
        report_df = pd.DataFrame(reports)
        report_df.to_csv("results/eval_report.csv", index=False)
        print("[+] Saved evaluation report to results/eval_report.csv")
        return report_df
    else:
        print("[!] No ground-truth provided; skip eval.")
        return None

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--text_json", default="results/text_predictions.json")
    parser.add_argument("--image_json", default="results/image_predictions.json")
    parser.add_argument("--out_json", default="results/fused_predictions.json")
    parser.add_argument("--weights", default="0.5,0.5;0.6,0.4;0.4,0.6")
    parser.add_argument("--gt_csv", default="data/gt_subset.csv")
    args = parser.parse_args()
    weight_pairs = [tuple(map(float, x.split(","))) for x in args.weights.split(";")]
    fused = fuse_all(args.text_json, args.image_json, weight_pairs, args.out_json)
    simple_eval(fused, args.gt_csv)
