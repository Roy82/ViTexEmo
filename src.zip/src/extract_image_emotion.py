"""
extract_image_emotion.py
- Uses a pretrained ViT classifier (timm) as a feature/emotion extractor example.
- This file demonstrates inference; for real use you would fine-tune ViT on emotion labels.
- Input: data/images_preprocessed/
- Output: results/image_predictions.json
"""
import argparse
import json
from pathlib import Path
import torch
import timm
import torchvision.transforms as T
from PIL import Image

EMO_CATEGORIES = ["Happy","Sad","Angry","Fearful","Disgust","Surprised","Neutral","Mixed"]

def load_model(model_name="vit_base_patch16_224", device="cpu"):
    model = timm.create_model(model_name, pretrained=True)
    model.eval()
    model.to(device)
    return model

def infer_image_emotion(model, image_path, device="cpu"):
    transform = T.Compose([
        T.Resize((224,224)),
        T.ToTensor(),
        T.Normalize(mean=(0.485,0.456,0.406), std=(0.229,0.224,0.225))
    ])
    img = Image.open(image_path).convert("RGB")
    x = transform(img).unsqueeze(0).to(device)
    with torch.no_grad():
        logits = model.forward_features(x)  # note: not a classifier head
        # Simple proxy: use mean feature to pick pseudo-label (DEMO ONLY)
        score = logits.mean().item()
    # Map proxy score to a category deterministically for demo
    idx = int(abs(int(score * 1000)) % len(EMO_CATEGORIES))
    return EMO_CATEGORIES[idx], float(score)

def run_image_inference(img_dir, out_json, model_name="vit_base_patch16_224", device="cpu"):
    model = load_model(model_name, device)
    results = []
    for p in sorted(Path(img_dir).glob("*")):
        try:
            emo, score = infer_image_emotion(model, str(p), device=device)
            results.append({"id": p.stem, "image": str(p), "image_emotion": emo, "score": score})
        except Exception as e:
            print("error", p, e)
    Path(out_json).parent.mkdir(parents=True, exist_ok=True)
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)
    print(f"[+] Saved image predictions to {out_json}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--img_dir", default="data/images_preprocessed")
    parser.add_argument("--out_json", default="results/image_predictions.json")
    parser.add_argument("--model_name", default="vit_base_patch16_224")
    parser.add_argument("--device", default="cpu")
    args = parser.parse_args()
    run_image_inference(args.img_dir, args.out_json, args.model_name, args.device)
